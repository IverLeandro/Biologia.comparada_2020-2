library(ape)
?ape
x <- paste("AJ5345", 26:49, sep = "")
x

x <- c("Z73494", x)

sylvia.seq <- read.GenBank(x)
head(sylvia.seq)
write.dna(sylvia.seq, "sylviaseq.fas", format = "fasta")
sylvia.seq.ali <- read.dna("sylviaseq.phy")
head(sylvia.seq.ali)
library(vegan)
library(cluster)
sylvia.dist1 = dist(sylvia.seq.ali)
head(sylvia.dist1)
t3<-(hclust(sylvia.dist1, method = "average", members=NULL))
plot(t3)
c3<-cophenetic(t3)
cor(sylvia.dist1,c3)
q()
